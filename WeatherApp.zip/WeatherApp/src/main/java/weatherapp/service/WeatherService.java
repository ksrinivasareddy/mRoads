package weatherapp.service;

import weatherapp.model.WeatherData;
import weatherapp.exception.CityNotFoundException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONObject;

public class WeatherService {
    // ✅ Replace with your active API key
    private static final String API_KEY = "23a5fcfca21d41f17e8787249d415490";
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric";

    public WeatherData getWeather(String city) throws Exception {
        // Encode city to handle spaces
        String encodedCity = URLEncoder.encode(city, "UTF-8");
        String urlString = String.format(BASE_URL, encodedCity, API_KEY);

        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();

        if (responseCode == 401) {
            throw new Exception("Invalid API key. Please check your API key.");
        } else if (responseCode == 404) {
            throw new CityNotFoundException("City not found: " + city);
        } else if (responseCode != 200) {
            throw new Exception("API error. Response code: " + responseCode);
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();

        JSONObject json = new JSONObject(response.toString());
        double temp = json.getJSONObject("main").getDouble("temp");
        int humidity = json.getJSONObject("main").getInt("humidity");
        String condition = json.getJSONArray("weather").getJSONObject(0).getString("main");

        return new WeatherData(city, temp, humidity, condition);
    }
}
