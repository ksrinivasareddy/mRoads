package weatherapp.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class TestAPIKey {
    public static void main(String[] args) {
        try {
            String key = "73973115e0f5b3136fac7c5eb6bed640"; // your API key
            String city = "London,uk";

            // Encode city name to handle spaces
            String encodedCity = URLEncoder.encode(city, "UTF-8");
            String urlStr = "https://api.openweathermap.org/data/2.5/weather?q=" + encodedCity + "&appid=" + key + "&units=metric";

            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            System.out.println("HTTP Response Code: " + responseCode);

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
