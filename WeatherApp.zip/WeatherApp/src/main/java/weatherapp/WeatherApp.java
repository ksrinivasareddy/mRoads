package weatherapp;

import weatherapp.service.WeatherService;
import weatherapp.model.WeatherData;
import weatherapp.exception.CityNotFoundException;

import java.util.Scanner;

public class WeatherApp {
    public static void main(String[] args) {
        WeatherService service = new WeatherService();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Weather Dashboard!");
        System.out.println("Enter city name (e.g., Mumbai,in or London,uk). Type 'exit' to quit.");

        while (true) {
            System.out.print("City: ");
            String cityInput = scanner.nextLine().trim();

            if (cityInput.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            if (cityInput.isEmpty()) {
                System.out.println("Please enter a valid city name.");
                continue;
            }

            try {
                WeatherData data = service.getWeather(cityInput);
                System.out.println("\n--- Weather Info ---");
                System.out.println("City: " + data.getCity());
                System.out.println("Temperature: " + data.getTemperature() + " °C");
                System.out.println("Humidity: " + data.getHumidity() + " %");
                System.out.println("Condition: " + data.getCondition());
                System.out.println("-------------------\n");
            } catch (CityNotFoundException e) {
                System.out.println("Error: City not found. Please try again with a valid city or city,country code.");
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        }

        scanner.close();
    }
}
